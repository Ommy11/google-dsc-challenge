package com.example.greenroutine;

public interface Command{

    public void execute();

}
