package com.example.greenroutine;

interface FastTest {
}

interface SlowTest {
}
