# Our Green Routine ![](https://github.com/mpontikes/Our-Green-Routine/workflows/Android%20CI/badge.svg)
The purpose of Our Green Routine is to inform users on how to properly recycle materials and how to better understand their environmental impact. Our app will be a one-stop-shop for environmental tools such as a carbon footprint tracker, recycling information, and personal climate action planning.

Project Pitch and Phasing:
https://docs.google.com/document/d/1JN4AKdx0w8f630izijABavwlDtphBrR8HyH6Q1gJ7RA/edit?usp=sharing
